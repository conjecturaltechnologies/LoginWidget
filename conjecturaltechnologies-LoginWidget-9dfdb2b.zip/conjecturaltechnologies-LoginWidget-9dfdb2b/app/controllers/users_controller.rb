class LettersController < ApplicationController
end
