class Message
  include MongoMapper::Document

  key :message, String

end
