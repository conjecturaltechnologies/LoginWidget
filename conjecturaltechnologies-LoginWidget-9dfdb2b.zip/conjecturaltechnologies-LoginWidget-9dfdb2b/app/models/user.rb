class User
  include MongoMapper::Document


end
