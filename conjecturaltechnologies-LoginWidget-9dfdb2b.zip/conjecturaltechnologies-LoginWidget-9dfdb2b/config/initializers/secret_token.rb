# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CloudFoundryRailsTutorial::Application.config.secret_token = '867d550d1dc5b093e790a2cd9cfbf59285baa9a7704042e9726e5e9d500f20ccbf6b85bec460f6c7ea50567a40fc4a48f161dd1cd081301cc662b4fd625b74aa'
